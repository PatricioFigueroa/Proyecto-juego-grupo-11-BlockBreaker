package com.mygdx.game.CarpetaInterfaces;


import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public interface DibujarElementos {
	    public void draw(SpriteBatch batch) ;	         
}
