package com.mygdx.game.CarpetaInterfaces;

public interface MovimientoElementos {
	
	   public boolean estaQuieto();
	   
	   public void setEstaQuieto(boolean bb);
	   
	   public void update() ;	   
}
